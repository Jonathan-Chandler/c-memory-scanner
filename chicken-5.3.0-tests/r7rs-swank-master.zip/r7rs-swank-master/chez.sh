#!/bin/bash
echo '(import (chez-swank)) (start-swank)' | chez-scheme --libdirs '.:/home/nex/scheme/chez'

