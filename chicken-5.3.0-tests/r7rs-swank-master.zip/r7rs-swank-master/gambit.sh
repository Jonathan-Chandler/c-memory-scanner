#!/bin/bash
gsi gambit-swank.sld
