#!/bin/bash
racket -I r7rs racket-swank.sld
