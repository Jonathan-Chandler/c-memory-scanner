#!/bin/bash
kawa -f kawa-swank.sld -e '(import (kawa-swank)) (start-swank 4005)'
