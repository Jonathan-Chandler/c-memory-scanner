#!/bin/bash
cyclone cyclone-swank.sld
icyc -p '(import (cyclone-swank))' # (start-swank "/tmp/cyclone-port.txt")
