#!/bin/bash
bigloo -call/cc bigloo-swank.scm
echo does not work yet
