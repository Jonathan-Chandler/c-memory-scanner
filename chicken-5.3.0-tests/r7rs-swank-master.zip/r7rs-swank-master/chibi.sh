#!/bin/bash
chibi-scheme  -A . -m '(chibi-swank)' -e '(start-swank)'
